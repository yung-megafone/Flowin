
## v1.6 - Pre-Sort + Real Dark Mode Fix

- Replaced the incorrect 18 pre-sort checkboxes with only `West Pre-Sort` and `East Pre-Sort`.
- Each selected pre-sort line now counts as one eighteenth of inbound line capacity.
- Pre-Sort goal math uses `PID Goal / 9 / 18` as the one-hour line goal.
- Pre-Sort performance math uses `Previous 15 Min Cartons / 18` per selected pre-sort line.
- Added the missing dark-mode toggle functions and persistent light/dark preference.

# Changelog

All notable changes to this project are documented here.

## v1.5 — Repo rebuild + ICLT update

- Reorganized the project into a general Flow Desk / Flow PG tools repository.
- Moved userscripts into `tools/browser-userscripts/`.
- Moved current HTML tools into `tools/web-apps/`.
- Added `archive/` for old versions.
- Added documentation pages under `docs/tools/`.
- Added updated ICLT / Carton Loss Tracker with Pre-Sort support and dark mode.

## v1.1.5 — AutoGen testing

- Added AutoGen userscript for ticket title suggestions.
- Added CA number support.
- Added tracking-title option.
- Added TAB key autofill behavior.

## v1.1 — ClipIt standalone

- Added Copy Ticket Info button.
- Added toast notifications.

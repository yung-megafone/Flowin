# Flowin — Flow Desk / Flow PG Tools

Flowin is a personal toolbox for Flow Desk, Flow PG, inbound dock tracking, ticket formatting, and other small workflow helpers.

This repo started as **ClipIt**, but it is now structured as a general home for flow tools so each small utility does not need its own GitHub repo.

## Current tools

| Tool | Type | Location | Purpose |
|---|---|---|---|
| ClipIt | Userscript | `tools/browser-userscripts/clipit/ClipIt.user.js` | Adds a quick-copy button for ticket title/link sharing. |
| AutoGen | Userscript | `tools/browser-userscripts/autogen/AutoGen.user.js` | Generates structured ticket title suggestions. |
| ICLT / Carton Loss Tracker | HTML web app | `tools/web-apps/carton-loss-tracker/ICLT.html` | Tracks downtime events, affected areas, and estimated carton loss. |

## Repo map

```text
Flowin/
├── tools/
│   ├── browser-userscripts/
│   │   ├── clipit/
│   │   └── autogen/
│   └── web-apps/
│       └── carton-loss-tracker/
├── docs/
│   └── tools/
├── archive/
│   ├── clipit/
│   └── carton-loss-tracker/
├── templates/
├── CHANGELOG.md
├── LICENSE
└── README.md
```

## Usage

### Userscripts

1. Install a userscript manager such as Tampermonkey or Greasemonkey.
2. Open the desired `.user.js` file from `tools/browser-userscripts/`.
3. Add it to the userscript manager.

### HTML tools

Open the `.html` file directly in a browser. The Carton Loss Tracker stores its working state in browser `localStorage`, so the log stays local to that browser/device.

## Adding a new tool

Use this convention:

```text
tools/
├── browser-userscripts/<tool-name>/<ToolName>.user.js
├── web-apps/<tool-name>/index.html
├── python/<tool-name>/<tool-name>.py
└── spreadsheets/<tool-name>/<tool-name>.xlsx
```

Then add a short doc page under `docs/tools/` and add the tool to the table above.

## Confidentiality / compliance note

This repo is intended for personal workflow helpers only. Do not add proprietary code, internal data, confidential process documents, screenshots, credentials, customer data, employee data, or anything that should not live in a personal GitHub repository.

## Disclaimer

This is a personal utility repo. It is not officially affiliated with, endorsed by, or supported by Amazon.

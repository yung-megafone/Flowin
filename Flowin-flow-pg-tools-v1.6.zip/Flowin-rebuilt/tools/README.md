# Tools

This folder contains the actual working tools.

## Browser userscripts
Install these with Tampermonkey/Greasemonkey.

- `browser-userscripts/clipit/ClipIt.user.js`
- `browser-userscripts/autogen/AutoGen.user.js`

## Web apps
Open these directly in a browser.

- `web-apps/carton-loss-tracker/ICLT.html`

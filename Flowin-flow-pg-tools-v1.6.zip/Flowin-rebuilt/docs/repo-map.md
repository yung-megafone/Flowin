# Repo Map

## `tools/`
The current working versions of tools live here. This is where future scripts and web apps should go.

## `docs/tools/`
One short markdown page per tool. Each page should explain what the tool does, how to run it, and what files matter.

## `archive/`
Old versions, retired one-off files, and historical backups. Nothing in this folder should be treated as the current production copy.

## `templates/`
Starter files or examples for future tools.

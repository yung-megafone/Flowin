# ICLT / Carton Loss Tracker

ICLT is a standalone HTML tool for tracking downtime events and estimating carton loss during inbound dock flow issues.

## Location

`tools/web-apps/carton-loss-tracker/ICLT.html`

## Current version notes

- Includes PID/PMT/DD area selection.
- Includes Pre-Sort tracking.
- Includes dark mode.
- Stores active shift state locally in the browser.
- Exports/copies a shift summary for Quip-style documentation.

## Pre-Sort math

The Pre-Sort line goal is based on:

```text
Total PID goal / 9 / 18 = 1-hour Pre-Sort line goal
```

This makes Pre-Sort trackable even though it does not connect directly to the PIDs.
